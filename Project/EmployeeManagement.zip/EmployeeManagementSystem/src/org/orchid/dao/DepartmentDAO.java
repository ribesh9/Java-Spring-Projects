
package org.orchid.dao;
import java.sql.*;
import java.util.*;
import org.orchid.model.Department;
import org.orchid.model.Employee;
import org.orchid.util.DBConnection;
public class DepartmentDAO {
    public void insert(Department d){
        try{
        Connection con = DBConnection.getConnection();
        String sql = "insert into department (dept_name,dept_phone) values(?,?)";
        PreparedStatement st = con.prepareStatement(sql);
        st.setString(1,d.getDept_name());
        st.setString(2,d.getDept_phone());
        st.execute();
        con.close();
    }
        catch(Exception ex){
                System.out.println("Error: " + ex);
                }
    }
    public List<Department> fetchRecords(){
        List<Department> dlist = new ArrayList();
     
        try{
            Connection con = DBConnection.getConnection();
            String sql = "Select * from department";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Department d = new Department();
                d.setDept_id(rs.getInt("dept_id"));
                d.setDept_name(rs.getString("dept_name"));
                d.setDept_phone(rs.getString("dept_phone"));
                dlist.add(d);
                
            }
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        return dlist;
    }
    public void update(Department d){
         try{
        Connection con = DBConnection.getConnection();
        String sql = "update department set dept_name=?,dept_phone=? where dept_id =?";
        PreparedStatement st = con.prepareStatement(sql);
        st.setString(1,d.getDept_name());
        st.setString(2,d.getDept_phone());
        st.setInt(3,d.getDept_id());
        st.execute();
        con.close();
    }
        catch(Exception ex){
                System.out.println("Error: " + ex);
                }
    }
      public void delete(Department d){
         try{
        Connection con = DBConnection.getConnection();
        String sql = "delete from department  where dept_id =?";
        PreparedStatement st = con.prepareStatement(sql);
        st.setInt(1,d.getDept_id());
        st.execute();
        con.close();
    }
        catch(Exception ex){
                System.out.println("Error: " + ex);
                }
    }
    
    
    
     public void insertintoEmp(Employee e){
            HashMap<Integer,String> m = new HashMap<Integer,String>();
            
        try{
        Connection con = DBConnection.getConnection();
        String sql1 = "Select * from department";
         PreparedStatement st1 = con.prepareStatement(sql1);
         ResultSet rs = st1.executeQuery();
         while(rs.next()){
             m.put(rs.getInt("dept_id"), rs.getString("dept_name"));
         }
        String sql = "insert into empmgmt (first_name,last_name,address,email,salary,dept_id,contact_no) values(?,?,?,?,?,?,?)";
        PreparedStatement st = con.prepareStatement(sql);
        st.setString(1,e.getFirst_name());
        st.setString(2,e.getLast_name());
        st.setString(3, e.getAddress());
        st.setString(4,e.getEmail());
        st.setInt(5, e.getSalary());
        st.setInt(6,e.getDept_id());
        st.setString(7, e.getContact_no());
        st.execute();
        con.close();
    }
        catch(Exception ex){
                System.out.println("Error: " + ex);
                }
    }
     
      public List<Employee> fetchRecordsofemp(){
        List<Employee> dlist = new ArrayList();
        try{
            Connection con = DBConnection.getConnection();
            String sql = "Select * from empmgmt";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Employee e = new Employee();
                e.setEmp_id(rs.getInt("emp_id"));
                e.setFirst_name(rs.getString("first_name"));
                e.setLast_name(rs.getString("last_name"));
                e.setAddress(rs.getString("address"));
                e.setEmail(rs.getString("email"));
                e.setSalary(rs.getInt("salary"));
                e.setDept_id(rs.getInt("dept_id"));
                e.setContact_no(rs.getString("contact_no"));
                dlist.add(e);
            }
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        return dlist;
    }
           
      }
      

