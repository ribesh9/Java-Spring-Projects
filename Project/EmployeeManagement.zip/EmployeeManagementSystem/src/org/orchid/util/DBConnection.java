package org.orchid.util;
import java.sql.*;
public class DBConnection {
    public static Connection getConnection(){
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/dbjava";
        String uname = "root";
        String pwd = "";
        try{
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url,uname,pwd);
       }
        catch(Exception ex){
            System.out.println(ex);
        }
        return con;
    }
}
