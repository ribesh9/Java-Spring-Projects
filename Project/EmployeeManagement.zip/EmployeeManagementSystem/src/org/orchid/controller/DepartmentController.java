
package org.orchid.controller;

import java.util.List;
import org.orchid.dao.DepartmentDAO;
import org.orchid.model.Department;
import org.orchid.model.Employee;

public class DepartmentController {
    
    
    public void insert(Department d){
        DepartmentDAO ddo= new DepartmentDAO();
        ddo.insert(d);
    }
    public List<Department> fetchRecords(){
        DepartmentDAO ddao = new DepartmentDAO();
        return ddao.fetchRecords();
    }
    
    public void update(Department d){
        DepartmentDAO ddo= new DepartmentDAO();
        ddo.update(d);
    }
    public void delete(Department d){
        DepartmentDAO ddo= new DepartmentDAO();
        ddo.delete(d);
    }
    
    
    public void insertintoEmp(Employee e){
        DepartmentDAO ddo = new DepartmentDAO();
        ddo.insertintoEmp(e);
    }
    public List<Employee> fetchRecordsofemp(){
        DepartmentDAO ddao = new DepartmentDAO();
        return ddao.fetchRecordsofemp();
    }
    
    
}
