package com.electronicsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectronicSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectronicSystemApplication.class, args);
	}

}
