package com.Esystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
