import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class HandlingFocusEvent  implements FocusListener{
    JTextField t1,t2;
    JFrame f1;
    
    HandlingFocusEvent (){
          f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
          t1 = new JTextField(20);
        f1.add(t1);
        t1.addFocusListener(this);     
       
        
        t2 = new JTextField(20);
        f1.add(t2);
        t2.addFocusListener(this);
        
        
        
        f1.setVisible(true);
    }
     public static void main(String[] args) {
        HandlingFocusEvent  ob = new HandlingFocusEvent ();
    }
public void focusGained(FocusEvent e){
    if(e.getSource()==t1)
        t1.setBackground(Color.LIGHT_GRAY);
    else if (e.getSource()==t2)
        t2.setBackground(Color.LIGHT_GRAY);
   
        
}
public void focusLost(FocusEvent e){
    if(e.getSource()== t1)
        t1.setBackground(Color.WHITE);
    else if (e.getSource() == t2)
        t2.setBackground(Color.WHITE);
}
}
