
import java.io.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class TextEditor implements ActionListener {

    JFrame f1;
    JMenu menu1, menu2;
    JMenuItem mi1, mi2, mi3, mi4;
    JMenuBar mbar;
    JTextArea t1;

    TextEditor() {
        f1 = new JFrame();
        f1.setSize(500, 500);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new BorderLayout());

        mbar = new JMenuBar();
        menu1 = new JMenu("File");
//        menu2 = new JMenu("Help");

        mi1 = new JMenuItem("New");
        mi1.addActionListener(this);

        mi2 = new JMenuItem("Open");
        mi2.addActionListener(this);

        mi3 = new JMenuItem("Save");
        mi3.addActionListener(this);

        mi4 = new JMenuItem("Exit");
        mi4.addActionListener(this);

        //we add menu item into menu
        menu1.add(mi1);

        //To add a line 
        menu1.addSeparator();

        menu1.add(mi2);
        menu1.addSeparator();

        menu1.add(mi3);
        menu1.addSeparator();

        menu1.add(mi4);

        //we add menu in menu bar
        mbar.add(menu1);
//        mbar.add(menu2);

        //add menu bar to frame
        f1.setJMenuBar(mbar);

        t1 = new JTextArea();
        JScrollPane jp = new JScrollPane(t1);
        f1.add(jp);
        t1.setLineWrap(true);

        //To open file menu using Alt + F
//        menu1.setMnemonic('F');
        //To add Ctrl+E shortcut for Exit
        mi4.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));
        //To add Ctrl+N shortcut for New
        mi1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
        
        mi3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
        
        mi4.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        TextEditor ob = new TextEditor();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == mi1) {
            t1.setText("");
        } else if (e.getSource() == mi2) {
            JFileChooser jfc = new JFileChooser();
            jfc.showOpenDialog(f1);
            String filename = jfc.getSelectedFile()+"";
            try{
                FileReader fr = new FileReader(filename);
                String content = "";
                int ch;
                while((ch=fr.read())!= -1){
                    content +=(char)ch;
//                    content = content+(char)ch;
                }
                fr.close();
                t1.setText(content);
            }
            catch (Exception ex){
                System.out.println(ex);
            }
        } else if (e.getSource() == mi3) {
            JFileChooser jfc = new JFileChooser();
            jfc.showSaveDialog(f1);
            String filename = jfc.getSelectedFile() + "";
            try {
                FileWriter fw = new FileWriter(filename);
                String content = t1.getText();
                fw.write(content);
                fw.close();
            } catch (Exception ex) {
                System.out.println(ex);
            }
        } else if (e.getSource() == mi4) {
            System.exit(0);
        }
    }
}
