import javax.swing.*;
public class MyFrame2 extends JFrame {
        MyFrame2(){
                
                setTitle("This is it");
                setSize(400,400); //setSize(width,length);
                //The file doesn't stop runing, the file runs in the background thus we use setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Makes the file stop running after we close the file 
                setVisible(true);// if setVisible is not true then it doesn't show
                setResizable(false);// does not allow the frame to be resized by the user
                
        }
        public static void main(String[] args) {
            MyFrame2 ob = new MyFrame2();
    }
}
