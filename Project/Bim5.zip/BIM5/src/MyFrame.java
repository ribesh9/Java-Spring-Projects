import javax.swing.*;
public class MyFrame  {
        JFrame f1;
        MyFrame(){
                f1 = new JFrame();
                //OR we can use
                f1.setTitle("This is it");
                f1.setSize(400,400); //setSize(width,length);
                //The file doesn't stop runing, the file runs in the background thus we use setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //Makes the file stop running after we close the file 
                f1.setVisible(true);// if setVisible is not true then it doesn't show
                f1.setResizable(false);// does not allow the frame to be resized by the user
                
        }
        public static void main(String[] args) {
            MyFrame ob = new MyFrame();
    }
}
