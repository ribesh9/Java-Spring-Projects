
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class ClassWork2 implements ActionListener{//implements ItemListener {

    JFrame f1;
    JComboBox cb;
    JTextField t1;

    ClassWork2() {
        f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(new FlowLayout());

        String f[] = {"Select a option", "1", "2", "3","4","5","6","7","8","9","10"};
        cb = new JComboBox(f);
        f1.add(cb);
//        cb.addItemListener(this);
        cb.addActionListener(this);
        cb.setMaximumRowCount(5);// making the scroll down after 5th position of the item

        t1 = new JTextField(20);
        f1.add(t1);

        f1.setVisible(true);
    }

    public static void main(String[] args) {
        ClassWork2 ob = new ClassWork2();
    }

//    public void itemStateChanged(ItemEvent e) {
//        String item = cb.getSelectedItem() + "";
//        t1.setText(item);
//    }
    
    
    public void actionPerformed(ActionEvent e) {
        String item = cb.getSelectedItem() + "";
        t1.setText(item);
    }
}
