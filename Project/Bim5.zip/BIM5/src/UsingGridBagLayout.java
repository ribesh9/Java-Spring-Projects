
import javax.swing.*;
import java.awt.*;

public class UsingGridBagLayout {

    JFrame f1;
    JButton b1, b2, b3, b4, b5,b6,b7;

    UsingGridBagLayout() {
        f1 = new JFrame();
        f1.setSize(400, 400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        b1 = new JButton("1");
        g.gridx=0;
        g.gridy = 0;
        f1.add(b1,g);
        b2 = new JButton("2");
        g.gridx=1;
        g.gridy = 0;
        f1.add(b2,g);
        b3 = new JButton("3");
        g.gridx=2;
        g.gridy = 0;
        f1.add(b3,g);
        b5 = new JButton("5");
        g.gridx=2;
        g.gridy = 1;
        f1.add(b5,g);
        b6 = new JButton("6");
        g.gridx=2;
        g.gridy = 2;
        f1.add(b6,g);
        b7 = new JButton("7");
        g.gridx=0;
        g.gridy = 3;
        g.gridwidth = 3;
        g.fill = GridBagConstraints.HORIZONTAL;
        f1.add(b7,g);
        b4 = new JButton("4");
        g.gridx=0;
        g.gridy = 1;
        g.gridwidth=2;
        g.gridheight=2;
        g.fill= GridBagConstraints.BOTH;
        f1.add(b4,g);
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        UsingGridBagLayout ob = new UsingGridBagLayout();
        
    }
}
