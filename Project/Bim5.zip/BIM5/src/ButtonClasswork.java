import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
public class ButtonClasswork implements ActionListener {
    JButton b1,b2,b3,b4;
    JFrame f1;
    JTextField t1,t2,t3;
    JLabel l1,l2,l3;
    
 ButtonClasswork() {
        f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        l1 = new JLabel ("Num1");
        f1.add(l1);
        
        t1 = new JTextField(20);
        f1.add(t1);
        
        l2 = new JLabel ("Num2");
        f1.add(l2);
        
        t2 = new JTextField(20);
        f1.add(t2);
        
        l3 = new JLabel ("Result");
        f1.add(l3);
        
        t3 = new JTextField(20);
        f1.add(t3);
        t3.setEditable(false);

         b1 = new JButton("Add");
        f1.add(b1);
        b1.addActionListener(this);     
       
        
        b2 = new JButton("Sub");
        f1.add(b2);
        b2.addActionListener(this);
        
         b3 = new JButton("Mult");
        f1.add(b3);
        b3.addActionListener(this);
        
         b4 = new JButton("Div");
        f1.add(b4);
        b4.addActionListener(this);
        
//        f1.pack();
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        ButtonClasswork ob = new ButtonClasswork();
    }
public void actionPerformed(ActionEvent e){
    int a = Integer.parseInt(t1.getText()); // Where the getText() method only takes the string value.
    int b = Integer.parseInt(t2.getText());
    if(e.getSource()== b1){
        int c = a+b;
        t3.setText(c+"");//The setText() method only takes the string value thus we concate the integer value.
    }
    
    else if (e.getSource()== b2){
        int c = a-b;
        t3.setText(c+"");
    } 
    
    else if (e.getSource()== b3){
        int c = a*b;
        t3.setText(c+"");
    } 
    
    else if (e.getSource()== b4){
        int c = a/b;
        t3.setText(c+"");
    } 
        
}
}

