import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class BgColorChange  implements ActionListener{
    JButton b1,b2,b3;
    JFrame f1;
    
    BgColorChange(){
          f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
          b1 = new JButton("Red");
        f1.add(b1);
        b1.addActionListener(this);     
       
        
        b2 = new JButton("Green");
        f1.add(b2);
        b2.addActionListener(this);
        
        b3 = new JButton("Blue");
        f1.add(b3);
        b3.addActionListener(this);
        
        f1.setVisible(true);
    }
     public static void main(String[] args) {
        BgColorChange ob = new BgColorChange();
    }
public void actionPerformed(ActionEvent e){
   
    if(e.getSource()== b1){
       b1.setBackground(Color.red);
    }
    
    else  if(e.getSource()== b2){
       b2.setBackground(Color.green);
    }
    
    else if(e.getSource()== b3){
       b3.setBackground(Color.blue);
    }
        
}
}
