import java.awt.*;
import java.awt.event.*;
public class AWTMenu extends WindowAdapter{
    Frame f1;
    MenuBar mb;
    Menu m1;
    Menu m2;
    MenuItem t1,t2,t3,t4,t5;
    AWTMenu(){
        f1= new Frame();
        f1.setSize(400,400);
        f1.addWindowListener(this);
        
        mb  = new MenuBar();
        
        m1 = new Menu ("File");
        m2 = new Menu("Help");
        
        t1 = new MenuItem("New");
        t2 = new MenuItem("Open");
        t3 = new MenuItem("Save");
        t4 = new MenuItem("Exit");
        t5 = new MenuItem("About Us");
        
        m1.add(t1);
        m1.add(t2);
        m1.add(t3);
        m1.add(t4);
        m2.add(t5);
        
        mb.add(m1);
        mb.add(m2);
        
        f1.setMenuBar(mb);
        
        f1.setVisible(true);
        
    }
    public static void main(String[] args) {
        AWTMenu ob = new AWTMenu();
    }
    public void windowClosing(WindowEvent e){
        f1.dispose();
    }
}
