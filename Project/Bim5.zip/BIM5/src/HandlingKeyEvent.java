import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class HandlingKeyEvent  extends KeyAdapter{
    //We can override the other unneccesary method by using the Adapter class.
    /*In this program we removed public void keyPressed(KeyEvent e) and public void keyTyped(KeyEvent e)
    and used only the needed method which is public void keyReleased(KeyEvent e).
    The Adapter class is important for exam and explanation*/
    JTextField t1,t2;
    JFrame f1;
    
    HandlingKeyEvent (){
          f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
          t1 = new JTextField(20);
        f1.add(t1);
        t1.addKeyListener(this);     
       
        
        t2 = new JTextField(20);
        f1.add(t2);      
        
        
        f1.setVisible(true);
    }
     public static void main(String[] args) {
        HandlingKeyEvent  ob = new HandlingKeyEvent ();
    }
public void keyReleased(KeyEvent e){
   t2.setText(t1.getText());
}
}
