import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class EventButtonTextbox implements ActionListener{

    JButton b1,b2;
    JFrame f1;
    JTextField t1;
    EventButtonTextbox() {
        f1 = new JFrame();
        f1.setSize(400, 400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());

        t1 = new JTextField(20);
        f1.add(t1);
//        t1.addActionListener(this);
        
        b1 = new JButton("Ok");
        f1.add(b1);
        b1.addActionListener(this);
        
        b2 = new JButton("Cancel");
        f1.add(b2);
        b2.addActionListener(this);
        
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        EventButtonTextbox ob = new EventButtonTextbox();
    }
public void actionPerformed(ActionEvent e){
    if(e.getSource()== b1){
        t1.setText("You clicked me");
    }
    
    else 
        t1.setText("");
}
}
