import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class UsingCustomDialog implements ActionListener {
    JFrame f1;
    JButton b1;
    
    UsingCustomDialog(){
        f1 = new JFrame();
        f1.setSize(400,400);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        b1 = new JButton("About us");
        f1.add(b1);
        b1.addActionListener(this);
        
        f1.setVisible(true);
    }
    public static void main(String[] args) {
        UsingCustomDialog ob =new UsingCustomDialog();
    }
    public void actionPerformed(ActionEvent e){
        JDialog d1 = new JDialog(f1,"Email us in",true);
        d1.setSize(200,200);
        d1.setLayout(new FlowLayout());
        JLabel l1 = new JLabel("Email: abc.@gmail.com");
        d1.add(l1);
        d1.setVisible(true);
    }
}
