
import javax.swing.*;
public class UsingDialogBox {
    public static void main(String[] args) {
        int a = Integer.parseInt(JOptionPane.showInputDialog("Enter a number"));
        int b = Integer.parseInt(JOptionPane.showInputDialog("Enter second number"));
        int c = a+b;
        JOptionPane.showMessageDialog(null, "Result is "+c);
        int choice = JOptionPane.showConfirmDialog(null,"Are you sure");
        System.out.println(choice);
        UsingDialogBox ob = new UsingDialogBox();
    }
}
