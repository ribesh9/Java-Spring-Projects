
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class UsingRadioButtonAndCheckBox implements ActionListener {

    JFrame f1;
    JButton b1;
    JComboBox cb;
    JRadioButton r1, r2;
    JCheckBox c1, c2, c3;
    JTextField t1;
    JLabel l1, l2, l3, l4;
    JPanel p1, p2;

    UsingRadioButtonAndCheckBox() {
        f1 = new JFrame();
//        f1.setSize(400, 400);
        f1.setBounds(100, 100, 400, 250);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(null);

        l1 = new JLabel("Name");
        l1.setBounds(10, 10, 80, 25);
        f1.add(l1);

        t1 = new JTextField(20);
        t1.setBounds(100, 10, 200, 25);
        f1.add(t1);

        l2 = new JLabel("Faculty");
        l2.setBounds(10, 45, 80, 25);
        f1.add(l2);

        String f[] = {"Select a Option", "BIM", "BBM", "CSIT", "BCA"};
        cb = new JComboBox(f);
        cb.setBounds(100, 45, 120, 25);
        f1.add(cb);

        l3 = new JLabel("Gender");
        l3.setBounds(10, 70, 80, 25);
        f1.add(l3);

        r1 = new JRadioButton("Male");
        r1.setBounds(100, 70, 80, 25);
        f1.add(r1);
        r2 = new JRadioButton("Female");
        r2.setBounds(180, 70, 80, 25);
        f1.add(r2);

        ButtonGroup b = new ButtonGroup();
        b.add(r1);
        b.add(r2);

        l4 = new JLabel("Hobbies");
        l4.setBounds(10, 105, 80, 25);
        f1.add(l4);

        c1 = new JCheckBox("Music");
        c1.setBounds(100, 105, 80, 25);
        f1.add(c1);
        c2 = new JCheckBox("Sports");
        c2.setBounds(180, 105, 80, 25);
        f1.add(c2);
        c3 = new JCheckBox("Travelling");
        c3.setBounds(260, 105, 80, 25);
        f1.add(c3);

        b1 = new JButton("Submit");
        b1.setBounds(100, 140, 80, 25);
        f1.add(b1);
        b1.addActionListener(this);

        f1.setVisible(true);
    }

    public static void main(String[] args) {
        UsingRadioButtonAndCheckBox ob = new UsingRadioButtonAndCheckBox();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            String T = t1.getText() + "";
            String item ="";
            if (cb.getSelectedIndex() == 0) {
                 item = "No item selected";
            } else {
                 item = cb.getSelectedItem() + "";
            }
            String g1;
            if (r1.isSelected()) {
                g1 = "Male";
            } else if (r2.isSelected()) {
                g1 = "Female";
            } else {
                g1 = "Not Choosen";
            }
            String h1 = "";
            if (c1.isSelected()) {
                h1 = "Music";
            }
            if (c2.isSelected()) {
                h1 += "Sports";
            }
            if (c3.isSelected()) {
                h1 += "Travelling";
            }
            if(cb.getSelectedIndex() == 0){
                JOptionPane.showMessageDialog(null,"Please choose a faculty");
            }
            
            else{
              JOptionPane.showMessageDialog(null, "Name: " + T + "\nFaculty: " + item +  "\nGender: " + g1 + "\nHobbies: " + h1);  
            }
        }
    }

}
