
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class UsingCardLayout implements ActionListener {

    JFrame f1;
    JButton b1, b2, b3;
    JPanel p1;
    CardLayout c;

    UsingCardLayout() {
        f1 = new JFrame();
        f1.setSize(400, 400);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        p1 = new JPanel();
        c = new CardLayout(20, 20);//c = new CardLayout();
        p1.setLayout(c);

        b1 = new JButton("Button1");
        b1.addActionListener(this);
        b2 = new JButton("Button 2");
        b2.addActionListener(this);
        b3 = new JButton("Button 3");
        b3.addActionListener(this);

        p1.add(b1); //        p1.add(b1,"one");
        p1.add(b2); //        p1.add(b2,"two");
        p1.add(b3); //        p1.add(b3,"Three");
        f1.add(p1);
        f1.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        c.next(p1);
//        c.show(p1, "one");
    }

    public static void main(String[] args) {
        UsingCardLayout ob = new UsingCardLayout();
    }
}
