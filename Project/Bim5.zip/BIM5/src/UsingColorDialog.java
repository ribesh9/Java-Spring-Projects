import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class UsingColorDialog implements ActionListener{
    JFrame f1;
    JButton b1;
    
    UsingColorDialog(){
    f1 = new JFrame();
    f1.setSize(400,400);
    f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    f1.setLayout(new FlowLayout());
    
    b1 = new JButton("Change Color");
    b1.addActionListener(this);
    f1.add(b1);
    
    
    f1.setVisible(true);
}
    public static void main(String[] args) {
        UsingColorDialog on = new UsingColorDialog();
    }
    public void actionPerformed(ActionEvent e){
        Color c  =    JColorChooser.showDialog(null,"Choose a color" , Color.yellow); //color is the itself in the java.awt class
        f1.getContentPane().setBackground(c);
    }
}
