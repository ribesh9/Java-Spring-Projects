package PractiseBIM5;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class StudentTab extends JPanel implements ActionListener{

    JLabel l1, l2;
    JTextField t1;
    JComboBox cb;
    JButton b1;
    
    StudentTab() {
        l1 = new JLabel("Name");
        l2 = new JLabel("Faculty");
        t1 = new JTextField(20);
        b1 = new JButton("Submit");
        b1.addActionListener(this);
        String f[] = {"Select a option", "BIM", "BBM"};
        cb = new JComboBox(f);

        add(l1);
        add(t1);
        add(l2);
        add(cb);
        add(b1);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == b1){
            String name = t1.getText();
            String f = "";
            if(cb.getSelectedIndex() == 0){
                 f = "Null";
            }
            else{
                f = cb.getSelectedItem()+"";
            }
            JOptionPane.showMessageDialog(null,"Name"+name+"\nFaculty"+f);
        }
    }
}

public class TabbedPaneEg {

    JFrame f1;
    JPanel jp;
    JTabbedPane p;

    TabbedPaneEg() {
        f1 = new JFrame();
        f1.setSize(500, 400);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        f1.setLayout(null);
        f1.setLayout(new FlowLayout());
        jp = new JPanel();
        StudentTab ob = new StudentTab();
        jp.add(ob);

        p = new JTabbedPane();
        p.addTab("Student", jp);
        f1.add(p);
        f1.setVisible(true);

    }

    public static void main(String[] args) {
        TabbedPaneEg ob = new TabbedPaneEg();
    }

}
