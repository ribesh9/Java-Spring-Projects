import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class EventButton implements ActionListener{

    JButton b1;
    JFrame f1;

    EventButton() {
        f1 = new JFrame();
        f1.setSize(400, 400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());

        b1 = new JButton("Ok");
        f1.add(b1);

        b1.addActionListener(this);
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        EventButton ob = new EventButton();
    }
public void actionPerformed(ActionEvent e){
    JOptionPane.showMessageDialog(null, "You Clicked Me"); //Screen ko center ma
//    JOptionPane.showMessageDialog(f1, "You Clicked Me"); Frame ko center ma 
}
}
