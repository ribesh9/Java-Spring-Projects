
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class SwingMenu implements ActionListener {

    JFrame f1;
    JMenu menu1, menu2;
    JMenuItem mi1, mi2, mi3;
    JMenuBar mbar;

    SwingMenu() {
        f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());

        mbar = new JMenuBar();
        menu1 = new JMenu("File");
        menu2 = new JMenu("Help");
        mi1 = new JMenuItem("New");
        mi1.addActionListener(this);
        mi2 = new JMenuItem("Exit");
        mi2.addActionListener(this);
        mi3 = new JMenuItem("About Us");

        //we add menu item into menu
        menu1.add(mi1);

        //To add a line 
        menu1.addSeparator();

        menu1.add(mi2);
        menu2.add(mi3);

        //we add menu in menu bar
        mbar.add(menu1);
        mbar.add(menu2);

        //add menu bar to frame
        f1.setJMenuBar(mbar);

        //To open file menu using Alt + F
        menu1.setMnemonic('F');

        //To add Ctrl+E shortcut for Exit
        mi2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));

        //To add Ctrl+N shortcut for New
        mi1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));

        f1.setVisible(true);
    }

    public static void main(String[] args) {
        SwingMenu ob = new SwingMenu();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == mi2) {
            System.exit(0);
        } else if (e.getSource() == mi1) {
            new ClassWork2();
        }
    }
}
