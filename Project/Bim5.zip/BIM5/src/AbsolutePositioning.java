import java.awt.*;
import javax.swing.*;
public class AbsolutePositioning {
        JFrame f1;
        JButton b1,b2;
        JLabel L1,L2,L3,L4;
        JTextField t1,t2,t3;
        JComboBox cb;
        
        
        AbsolutePositioning(){
            f1= new JFrame();
//            f1.setSize(800,400);
            f1.setBounds(100,100,400,400);
            f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f1.setLayout(null);
            
            L1 = new JLabel("Name");
            L1.setBounds(10,10,80,25);
            f1.add(L1);
            
            t1 = new JTextField();
            t1.setBounds(100,10,200,25);
            f1.add(t1);
            
            L2 = new JLabel("Age");
            L2.setBounds(10,45,80,25);
            f1.add(L2);
            
            t2 = new JTextField();
            t2.setBounds(100,45,80,25);
            f1.add(t2);
            
            L3 = new JLabel("Email");
            L3.setBounds(10,80,80,25);
            f1.add(L3);
            
            t3 = new JTextField();
            t3.setBounds(100, 80, 200, 25);
            f1.add(t3);
            
            L4 = new JLabel("Faculty");
            L4.setBounds(10,120,80,25);
            f1.add(L4);
            
            String f[]={"Select a option","BIM","BCA","Csit"};
            cb = new JComboBox(f);
            cb.setBounds(100,120,200,25);
            f1.add(cb);
            
            b1 = new JButton("Submit");
            b1.setBounds(100,160,80,25);
            
            f1.add(b1);
            
            b2 = new JButton("Cancel");
            b2.setBounds(200,160,80,25);
            f1.add(b2);
            
//            f1.pack();  
            f1.setVisible(true);
        }
        public static void main(String[] args) {
        AbsolutePositioning ob = new AbsolutePositioning();
    }
}
