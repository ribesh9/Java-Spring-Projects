import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class JListSwing implements ListSelectionListener{

    JFrame f1;
    JList l;
    JTextField t1;

    JListSwing() {
        f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(new FlowLayout());

        String f[] = {"Select a option", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        l = new JList(f);
//        l.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//        f1.add(l);
           l.setVisibleRowCount(5);
        JScrollPane jp = new JScrollPane(l);
        f1.add(jp);
        l.addListSelectionListener(this);
//        cb.addItemListener(this);
//        l.addActionListener(this);
//        l.setMaximumRowCount(5);// making the scroll down after 5th position of the item

        t1 = new JTextField(20);
        f1.add(t1);

        f1.setVisible(true);
        
    }

    public static void main(String[] args) {
        JListSwing ob = new JListSwing();
    }


    public void valueChanged(ListSelectionEvent e) {
        
            String item = l.getSelectedValuesList()+"";
            t1.setText(item);
}
}
