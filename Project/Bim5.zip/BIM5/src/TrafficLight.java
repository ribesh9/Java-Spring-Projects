
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TrafficLight implements ActionListener {

    JFrame f1;
    JTextArea t1, t2, t3;
    JButton b1;
    Timer t = new Timer(1000, this);
    int state = 0;

    TrafficLight() {
        f1 = new JFrame();
        f1.setSize(500, 500);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        b1 = new JButton("Start");
        f1.add(b1);
        b1.addActionListener(this);
        t1 = new JTextArea(25, 25);
        f1.add(t1);
        t1.setBackground(Color.black);

        t2 = new JTextArea(25, 25);
        f1.add(t2);
        t2.setBackground(Color.black);

        t3 = new JTextArea(25, 25);
        f1.add(t3);
        t3.setBackground(Color.black);
        
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        TrafficLight ob = new TrafficLight();
    }

    public void paint(Graphics g) {
//            g.setBackground(Color.black);
    }

    public void actionPerformed(ActionEvent e) {
            t.start();
            state = (state +1)%3;
            if(state==1){
            t1.setBackground(Color.red);
            t2.setBackground(Color.black);
            t3.setBackground(Color.black);
            }
            if(state == 2){
                t2.setBackground(Color.yellow);
                t1.setBackground(Color.black);
                t3.setBackground(Color.black);
            }
            if(state == 0){
                t3.setBackground(Color.green);
                t1.setBackground(Color.black);
                t2.setBackground(Color.black);
            }
        
    }
}
