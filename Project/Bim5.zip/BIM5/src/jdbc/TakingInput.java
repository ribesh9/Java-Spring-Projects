/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;
import java.sql.*;
import java.util.*;
public class TakingInput {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        System.out.println("Enter the id");
        int id = ob.nextInt();
        System.out.println("Enter the name");
        String name = ob.next();
        System.out.println("Enter the address");
        String address = ob.next();
        System.out.println("Enter the age");
        int age = ob.nextInt();
        
          String url = "jdbc:mysql://localhost:3306/dbjava";
            String uname = "root"; //user name
            String pwd = ""; // password
            try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                    
                String sql = "insert into student values(?,?,?,?)";   
               PreparedStatement st = con.prepareStatement(sql);
                st.setInt(1, id);
                st.setString(2, name);
                st.setString(3,address);
                st.setInt(4,age);
                st.execute();
                con.close();
            }
            catch(Exception ex){
                System.out.println(ex);
            }
    }
}
