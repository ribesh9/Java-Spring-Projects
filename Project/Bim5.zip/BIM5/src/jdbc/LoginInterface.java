package jdbc;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class LoginInterface implements ActionListener{
    JFrame f1;
    JLabel l1,l2;
    JTextField t1;
    JPasswordField p1;
    JButton b1;
    
    LoginInterface(){
        f1 = new JFrame();
        f1.setBounds(100,100,500,500);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(null);
        
        l1= new JLabel("Username");
        l1.setBounds(10,10,80,25);
        f1.add(l1);
        
        t1 = new JTextField(20);
        t1.setBounds(120,10,200,25);
        f1.add(t1);
        
        l2 = new JLabel("Password");
        l2.setBounds(10,80,80,25);
        f1.add(l2);
        
        p1 = new JPasswordField(20);
        p1.setBounds(120,80,200,25);
        f1.add(p1);
        
        b1 = new JButton("Login");
        b1.setBounds(170,120,80,25);
        b1.addActionListener(this);
        f1.add(b1);
        
        f1.setVisible(true);
    }
    public static void main(String[] args) {
        new LoginInterface();
    }
    public void actionPerformed(ActionEvent e){
        String username = t1.getText();
        String password = new String(p1.getPassword());
        //char array lai string ma pass garne string ko constructor call garera
        
           String url = "jdbc:mysql://localhost:3306/dbjava";
        String uname = "root";
        String pwd = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, pwd);
            String sql = "select * from login where username =? and password =?";
            //String sql = "select * from login where username = '"+username+"' and password = '"+password +"'";
            //The above statement can have sql injection due to the single quote thus using username = ram' or 1=1-- ; the attack is successfull
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1,username);
            st.setString(2,password);
            ResultSet rs = st.executeQuery();
            if(rs.next()){
                JOptionPane.showMessageDialog(null,"Login Succesfull");
            }
            else{
                JOptionPane.showMessageDialog(null,"Login Failed");
            }
            con.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
