package jdbc;
import java.sql.*;
import java.util.*;
public class TodoQn3 {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        System.out.println("Enter the id of the student");
        int id = ob.nextInt();
        System.out.println("Enter the new age");
        int age = ob.nextInt();
        String url = "jdbc:mysql://localhost:3306/dbjava1";
        String uname = "root";
        String pwd = "";
         try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                    
                String sql = "update student set age = ? where id = ?";
                
                PreparedStatement st = con.prepareStatement(sql);
                st.setInt(1, age);
                st.setInt(2,id);
                st.execute();
         }
         catch(Exception ex){
             System.out.println(ex);
         }
    }
}
