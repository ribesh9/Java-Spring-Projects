package jdbc;
import java.sql.*;
public class InsetRecord {
    
    public static void main(String[] args) {
            String url = "jdbc:mysql://localhost:3306/dbjava";
            String uname = "root"; //user name
            String pwd = ""; // password
            try{
                //add mysqldriver from the libary 
                //mysql connector jar file for new netbeans
                Class.forName("com.mysql.jdbc.Driver"); //keywork class is small letter, the Class having capital letter is itself class
                //driver must be downloaded from internet and kept in the project else exception is thrown;
                
                Connection con = DriverManager.getConnection(url,uname,pwd); //the connection is creater through driver manager
                //url try to connect to the database (dbjava) thus sql exception is created by mistakes such as port number mistake,database 
               //not found and the jdbc spelling error

//                String sql = "insert into student values (1,'Ribesh','Damauli',21)";


//                  To insert multiple records
//                   String sql = "insert into student values(2, 'Rosni', 'Syangja', 20), (3, 'Hari', 'ktm', 23), (4, 'Sita', 'bkt', 20)";


//                To update
//                    String sql = "update student set address ='pkr' where id = 4";

//                    To delete
                    String sql = "delete from student where id = 4";
                Statement st = con.createStatement();
                st.execute(sql);
                con.close();
            }
            catch(Exception ex){
                System.out.println(ex);
            }
    }
}
