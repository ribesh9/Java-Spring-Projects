package jdbc;
import java.sql.*;
public class TodoQn7 {
    
    public static void main(String[] args) {
            String url = "jdbc:mysql://localhost:3306/dbjava";
            String uname = "root"; 
            String pwd = ""; 
            try{
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(url,uname,pwd);
                CallableStatement cst = con.prepareCall("{call insert_records(?,?,?,?)}");
                cst.setInt(1, 201);
                cst.setString(2,"Ribesh");
                cst.setString(3,"Damauli");
                cst.setInt(4,21);
                cst.execute();
                con.close();
            }
            catch(Exception ex){
                System.out.println(ex);
            }
    }
}
