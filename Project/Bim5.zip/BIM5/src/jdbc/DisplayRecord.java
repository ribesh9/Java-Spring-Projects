
package jdbc;
import java.sql.*;
public class DisplayRecord {
    public static void main(String[] args) {
         String url = "jdbc:mysql://localhost:3306/dbjava";
            String uname = "root"; //user name
            String pwd = ""; // password
            try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                    
                String sql = "select * from student'";   
                Statement st = con.createStatement();
//                st.execute(sql); only executes the insert, update and delete

                ResultSet rs = st.executeQuery(sql);
                while(rs.next()){
                    System.out.println(rs.getString("id"));   //System.out.println(rs.getString(1));
                    System.out.println(rs.getString("name")); //System.out.println(rs.getString(2));
                    System.out.println(rs.getString("address")); //System.out.println(rs.getString(3));
                    System.out.println(rs.getString("age")); //System.out.println(rs.getString(4));
                }
                con.close();
            }
            catch(Exception ex){
                System.out.println(ex);
            }
    }
}
