package jdbc;
import java.sql.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TodoQn5 implements ActionListener{
      JFrame f1;
    JLabel l1;
    JButton b1;
    JTextField t1;
    
    TodoQn5(){
        f1 = new JFrame();
        f1.setSize(400,400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        l1 = new JLabel("Enter the id to delete");
        f1.add(l1);
        
        t1 = new JTextField(20);
        f1.add(t1);
        
        b1 = new JButton("Delete");
        b1.addActionListener(this);
        f1.add(b1);
        
        f1.setVisible(true);
    }
    public static void main(String[] args) {
       new TodoQn5();
    }
    public void actionPerformed(ActionEvent e){
         String url = "jdbc:mysql://localhost:3306/dbjava1";
        String uname = "root";
        String pwd = "";
         try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                 int id = Integer.parseInt(t1.getText());
                String sql = "delete from student where id >"+id;
                Statement st = con.createStatement();
                st.execute(sql);
                 JOptionPane.showMessageDialog(null,"Deleted");
                 t1.setText("");
                con.close();
         }
         catch(Exception ex){
             System.out.println(ex);
         }
    }
}