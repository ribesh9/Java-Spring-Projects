
package jdbc;
import java.sql.*;
import java.util.*;
public class TodoQn1 {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        String url = "jdbc:mysql://localhost:3306/dbjava1";
        String uname = "root";
        String pwd = "";
        try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                    
                String sql = "insert into student values(?,?,?,?)";   
               PreparedStatement st = con.prepareStatement(sql);
               for(int i =1 ;i<=5;i++){
                   System.out.println("Enter id, name, address and age");
                   int id = ob.nextInt();
                   String name = ob.next();
                   String address = ob.next();
                   int age = ob.nextInt();
                st.setInt(1, id);
                st.setString(2, name);
                st.setString(3,address);
                st.setInt(4,age);
                st.execute();
               }
                con.close();
        }
        catch(Exception ex){
            System.out.println(ex);
        }
    }
}
