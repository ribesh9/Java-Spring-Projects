package jdbc;
import java.sql.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TodoQn4 implements ActionListener {
    JFrame f1;
    JLabel l1;
    JButton b1;
    JTextField t1;
    
    TodoQn4(){
        f1 = new JFrame();
        f1.setSize(400,400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        l1 = new JLabel("Enter the age");
        f1.add(l1);
        
        t1 = new JTextField(20);
        f1.add(t1);
        
        b1 = new JButton("Check");
        b1.addActionListener(this);
        f1.add(b1);
        
        f1.setVisible(true);
    }
    public static void main(String[] args) {
       new TodoQn4();
    }
    public void actionPerformed(ActionEvent e){
         String url = "jdbc:mysql://localhost:3306/dbjava1";
        String uname = "root";
        String pwd = "";
         try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                 int age = Integer.parseInt(t1.getText());
                String sql = "select * from student where age >"+age;
                Statement st = con.createStatement();
//                PreparedStatement st = con.prepareStatement(sql);
//                st.setInt(1, age);
                ResultSet rs = st.executeQuery(sql);
                while(rs.next()){
                    System.out.print(rs.getString("id")+" ");   //System.out.println(rs.getString(1));
                    System.out.print(rs.getString("name")+" "); //System.out.println(rs.getString(2));
                    System.out.print(rs.getString("address")+" "); //System.out.println(rs.getString(3));
                    System.out.println(rs.getString("age")+" "); //System.out.println(rs.getString(4));
                }
                con.close();
         }
         catch(Exception ex){
             System.out.println(ex);
         }
    }
}
