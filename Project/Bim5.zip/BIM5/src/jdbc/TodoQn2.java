package jdbc;
import java.sql.*;
import java.util.*;
public class TodoQn2 {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        System.out.println("Enter the id of the student");
        int id = ob.nextInt();
        String url = "jdbc:mysql://localhost:3306/dbjava1";
        String uname = "root";
        String pwd = "";
         try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                    
                String sql = "delete from student where id = ?";
                PreparedStatement st = con.prepareStatement(sql);
                st.setInt(1,id);
                st.execute();
                con.close();
                /*
                Or alternative 
                String sql = "delete from student where id = "+id;
                Statement st = con.createStatement();
                st.execute(sql);
                */
         }
         catch(Exception ex){
             System.out.println(ex);
         }
    }
}
