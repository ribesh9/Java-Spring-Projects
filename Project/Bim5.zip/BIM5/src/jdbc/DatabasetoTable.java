package jdbc;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class DatabasetoTable implements ActionListener {

    JFrame f;
    JButton b;
    JTable t1;

    DatabasetoTable() {
        f = new JFrame();
        f.setSize(400, 400);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(new FlowLayout());

        b = new JButton("Load Data");
        b.addActionListener(this);
        f.add(b);

        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String url = "jdbc:mysql://localhost:3306/dbjava";
        String uname = "root";
        String pwd = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, pwd);
            String sql = "select * from student";
            Statement st = con.createStatement();
            //For jdk version may be different
            //Statement st = con.createStatement(ResultSet. TYPE_SCROLL_INSENSITIVE, ResultSet.TYPE_CONCUR_READ_ONLY);
            ResultSet rs = st.executeQuery(sql);
            String[] cols = {"ID", "Name", "Address", "Age"};
            int count =0;
            while(rs.next()){
                count++;
            }
            Object[][] data = new Object[count][4];
            int row = 0;
            rs.beforeFirst();
            while (rs.next()) {
                data[row][0] = rs.getString("id");
                data[row][1] = rs.getString("name");
                data[row][2] = rs.getString("address");
                data[row][3] = rs.getString("age");
                row++;
            }
            con.close();
            t1 = new JTable(data, cols);
            JScrollPane jp = new JScrollPane(t1);
            JDialog d1 = new JDialog(f, true);
            d1.setSize(600, 600);
            d1.setLayout(new FlowLayout());
            d1.add(jp);
            d1.setVisible(true);
//            f.add(jp);
//            f.setVisible(true);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static void main(String[] args) {
        new DatabasetoTable();
    }
}
