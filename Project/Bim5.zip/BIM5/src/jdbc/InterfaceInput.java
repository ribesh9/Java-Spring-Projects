
package jdbc;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class InterfaceInput implements ActionListener{
    JFrame f1;
    JButton b;
    JLabel l1,l2,l3,l4;
    JTextField t1,t2,t3,t4;
    
    InterfaceInput(){
        f1 = new JFrame();
        f1.setBounds(100,100,400,400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(null);
        
        l1 = new JLabel("Id");
        l1.setBounds(10,10,80,25);
        f1.add(l1);
        
        t1 = new JTextField();
        t1.setBounds(100,10,200,25);
        f1.add(t1);
        
        l2 = new JLabel("Name");
        l2.setBounds(10,50,80,25);
        f1.add(l2);
        
        t2 = new JTextField();
        t2.setBounds(100,50,200,25);
        f1.add(t2);
        
        l3 = new JLabel("Address");
        l3.setBounds(10,90,80,25);
        f1.add(l3);
        
        t3 = new JTextField();
        t3.setBounds(100,90,200,25);
        f1.add(t3);
        
        l4 = new JLabel("Age");
        l4.setBounds(10,130,80,25);
        f1.add(l4);
        
        t4 = new JTextField();
        t4.setBounds(100,130,200,25);
        f1.add(t4);
        
        b = new JButton("Submit");
        b.setBounds(150,170,80,25);
        b.addActionListener(this);
        f1.add(b);
        
        f1.setVisible(true);
    }
    public static void main(String[] args) {
        InterfaceInput ob = new InterfaceInput();
    }
    public void actionPerformed(ActionEvent e){
          String url = "jdbc:mysql://localhost:3306/dbjava";
            String uname = "root"; //user name
            String pwd = ""; // password
            int id = Integer.parseInt(t1.getText());
            String name = t2.getText();
            String address = t3.getText();
            int age =Integer.parseInt(t4.getText());
            try{
                Class.forName("com.mysql.jdbc.Driver");               
                Connection con = DriverManager.getConnection(url,uname,pwd); 
                    
                String sql = "insert into student values(?,?,?,?)";   
               PreparedStatement st = con.prepareStatement(sql);
                st.setInt(1, id);
                st.setString(2,name);
                st.setString(3,address);
                st.setInt(4,age);
                st.execute();
                con.close();
                JOptionPane.showMessageDialog(null,"Record Saved");
                t1.setText("");
                t2.setText("");
                t3.setText("");
                t4.setText("");
            }
            catch(Exception ex){
                System.out.println(ex);
            }
    }
}
