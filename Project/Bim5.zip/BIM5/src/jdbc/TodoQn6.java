package jdbc;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class TodoQn6 implements ActionListener{
      JFrame f;
    JButton b;
    JTable t1;
    TodoQn6(){
           f = new JFrame();
        f.setSize(400, 400);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLayout(new FlowLayout());

        b = new JButton("Load Data");
        b.addActionListener(this);
        f.add(b);

        f.setVisible(true);
    }
      public static void main(String[] args) {
        new TodoQn6();
    }
    public void actionPerformed(ActionEvent e){
              
           String url = "jdbc:mysql://localhost:3306/dbjava";
        String uname = "root";
        String pwd = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, uname, pwd);
            String sql = "select * from student";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            int cols = rsmd.getColumnCount();
            while(rs.next()){
                for(int i = 1;i<=cols;i++){
                    System.out.println(rs.getString(i));
                }
                    
            }
            con.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
