import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class UsingJToggleButton implements ItemListener{
    JToggleButton tb;
    UsingJToggleButton(){
        JFrame f1 = new JFrame();
        f1.setSize(400,400);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        tb = new JToggleButton("Press");
        f1.add(tb);
        tb.addItemListener(this);
        
        
        f1.setVisible(true);
    }
    public static void main(String[] args) {
        UsingJToggleButton ob = new UsingJToggleButton();
    }
    
    public void itemStateChanged(ItemEvent e){
        if(tb.isSelected()){
            tb.setText("On");
        }
        else{
            tb.setText("off");
            tb.setBackground(Color.red);
        }
    }
}
