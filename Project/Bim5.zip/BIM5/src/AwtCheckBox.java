
import java.awt.*;
import java.awt.event.*;

public class AwtCheckBox extends WindowAdapter implements ActionListener{

    Frame f1;
    Checkbox r1, r2, c1, c2;
    Choice cs;
    List lt;
    Label l1, l2, l3, l4, l5;
    Button b1;
    TextField t1;

    AwtCheckBox() {
        f1 = new Frame();
//        f1.setSize(400, 400);
        f1.addWindowListener(this);
        f1.setLayout(null);
        f1.setBounds(100,100,500,500);
        l1 = new Label("Name");
        l1.setBounds(10, 50, 80, 25);
        f1.add(l1);
        
        t1 = new TextField();
        t1.setBounds(100,50,200,25);
        f1.add(t1);
        
        l2 = new Label("Faculty");
        l2.setBounds(10, 80, 80, 25);
        f1.add(l2);
        
        cs = new Choice();
        cs.add("Select a Option");
        cs.add("BIM");
        cs.add("BBM");
        cs.setBounds(100, 80, 110, 25);
        f1.add(cs);
        
        l3 = new Label("Gender");
        l3.setBounds(10, 110, 80, 25);
        f1.add(l3);
        CheckboxGroup bg = new CheckboxGroup();
        r1 = new Checkbox("Male", bg, false);
        r2 = new Checkbox("Female", bg, false);
        r1.setBounds(100, 110, 80, 25);
        f1.add(r1);
        r2.setBounds(190, 110, 80, 25);
        f1.add(r2);

        l4 = new Label("Hobbies");
        l4.setBounds(10, 140, 80, 25);
        f1.add(l4);
        c1 = new Checkbox("Sports");
        c2 = new Checkbox("Music");
        c1.setBounds(100, 140, 80, 25);
        f1.add(c1);
        c2.setBounds(190, 140, 80, 25);
        f1.add(c2);
        

        l5 = new Label("Language");
        l5.setBounds(10, 170, 80, 25);
        f1.add(l5);
        lt = new List(4,true);
        lt.add("Nepali");
        lt.add("English");
        lt.add("Chinese");
        lt.add("Sanjali");
        lt.setBounds(100, 170, 80, 80);
        f1.add(lt);
        
        b1 = new Button("Submit");
        b1.addActionListener(this);
        b1.setBounds(100,255, 80, 25);
        f1.add(b1);

        f1.setVisible(true);
    }

    public static void main(String[] args) {
        AwtCheckBox ob = new AwtCheckBox();
    }

    public void windowClosing(WindowEvent e) {
        f1.dispose();
    }
    public void actionPerformed(ActionEvent e){
        String name = t1.getText()+"";
        String f = cs.getSelectedItem();
        String g = "";
        if(r1.getState()==true)
            g = "Male";
        else if(r2.getState() == true)
                g="Female";
        String h = "";
        if(c1.getState() == true){
            h = "Sports";
        }
        else if(c1.getState() == true){
            h+="Music";
        }
        String lan[]= lt.getSelectedItems();
        String lk = "";
        for(String a : lan){
            lk =lk + a;
        }
        System.out.println("Name: "+name+"\nFaculty: "+f+"\nGender: "+g+"\nHobbies: "+h+"\nLanguge: "+lk);
    }
}
