import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class TextFieldValues2  extends KeyAdapter{
    //We can override the other unneccesary method by using the Adapter class.
    /*In this program we removed public void keyPressed(KeyEvent e) and public void keyTyped(KeyEvent e)
    and used only the needed method which is public void keyReleased(KeyEvent e).
    The Adapter class is important for exam and explanation*/
    JTextField t1,t2;
    JLabel l1,l2;
    JFrame f1;
    JButton b1;
    
    TextFieldValues2 (){
          f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        l1 = new JLabel ("Name");
        f1.add(l1);
        
         t1 = new JTextField(20);
        f1.add(t1);
        t1.addKeyListener(this);     
       
        l2 = new JLabel ("Age");
        f1.add(l2);
        
        t2 = new JTextField(10);
        f1.add(t2);
        t2.addKeyListener(this);
        
        b1 = new JButton(new ImageIcon(getClass().getResource("images/one.png")));
        //Image must be of size 12*12 or 16*16
        f1.add(b1);
        
        f1.setVisible(true);
    }
     public static void main(String[] args) {
        TextFieldValues2  ob = new TextFieldValues2 ();
    }
public void keyTyped(KeyEvent e){
        char n = e.getKeyChar();
        if(e.getSource()== t1){
            if(!(n>='a' && n<='z' || n>='A' && n<='Z')){
                e.consume();
            }
        }
       else if(e.getSource()== t2){
            if(!(n>='0' && n<='9')){
                e.consume();
            }
          
        }
       }
public void keyReleased(KeyEvent e){
  String num = t2.getText();
            if(!(num.equals(""))){
            int a = Integer.parseInt(num);
            if(a<1 || a>100){
                JOptionPane.showMessageDialog(null, "Invalid age");
                t2.setText("");
            }
       }
}
}

