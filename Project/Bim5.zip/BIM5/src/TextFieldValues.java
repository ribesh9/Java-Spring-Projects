import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class TextFieldValues  extends KeyAdapter{
    //We can override the other unneccesary method by using the Adapter class.
    /*In this program we removed public void keyPressed(KeyEvent e) and public void keyTyped(KeyEvent e)
    and used only the needed method which is public void keyReleased(KeyEvent e).
    The Adapter class is important for exam and explanation*/
    JTextField t1,t2;
    JLabel l1,l2;
    JFrame f1;
    
    TextFieldValues (){
          f1 = new JFrame();
        f1.setSize(300, 250);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        l1 = new JLabel ("Name");
        f1.add(l1);
        
         t1 = new JTextField(20);
        f1.add(t1);
        t1.addKeyListener(this);     
       
        l2 = new JLabel ("Age");
        f1.add(l2);
        
        t2 = new JTextField(10);
        f1.add(t2);
        t2.addKeyListener(this);
        
        
        f1.setVisible(true);
    }
     public static void main(String[] args) {
        TextFieldValues  ob = new TextFieldValues ();
    }
public void keyTyped(KeyEvent e){
        char n = e.getKeyChar();
        if(e.getSource()== t1){
            if(!(n>='a' && n<='z' || n>='A' && n<='Z')){
                e.consume();
            }
        }
       else if(e.getSource()== t2){
            if(!(n>='0' && n<='9')){
                e.consume();
            }
        }
}
}
