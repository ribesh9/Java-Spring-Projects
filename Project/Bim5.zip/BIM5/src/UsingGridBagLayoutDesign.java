
import javax.swing.*;
import java.awt.*;

public class UsingGridBagLayoutDesign {

    JFrame f1;
    JButton b1, b2;
    JLabel l1, l2, l3, l4;
    JTextField t1, t2, t3;
    JPanel p1;

    UsingGridBagLayoutDesign() {
        f1 = new JFrame();
      //f1.setSize(800, 400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GridBagLayout gl = new GridBagLayout();
        f1.setLayout(gl);
        GridBagConstraints g = new GridBagConstraints();

        g.insets = new Insets(5, 5, 5, 5);

        l4 = new JLabel("Student Registration Form");
        g.gridx = 1;
        g.gridy = 0;
        gl.setConstraints(l4, g);
        f1.add(l4);
        Font f = new Font("Times New Roman", Font.BOLD, 20);
        Font f2 = new Font("Times New Roman", Font.ITALIC, 20);
        l4.setFont(f);
        l4.setFont(f2);

        l1 = new JLabel("Name");
        g.gridx = 0;
        g.gridy = 1;
        gl.setConstraints(l1, g);
        f1.add(l1);

        t1 = new JTextField(30);
        g.gridx = 1;
        g.gridy = 1;
        gl.setConstraints(t1, g);
        f1.add(t1);

        l2 = new JLabel("Age");
        g.gridx = 0;
        g.gridy = 2;
        g.anchor = GridBagConstraints.WEST;
        gl.setConstraints(l2, g);
        f1.add(l2);

        t2 = new JTextField(20);
        g.gridx = 1;
        g.gridy = 2;
        gl.setConstraints(t2, g);
        f1.add(t2);

        l3 = new JLabel("Email");
        g.gridx = 0;
        g.gridy = 3;
        gl.setConstraints(l3, g);
        f1.add(l3);

        t3 = new JTextField(30);
        g.gridx = 1;
        g.gridy = 3;
        gl.setConstraints(t3, g);
        f1.add(t3);

        p1 = new JPanel();

        b1 = new JButton("Submit");
//        g.gridx=1;
//        g.gridy=3;
//        gl.setConstraints(b1,g);
//        f1.add(b1);

        b2 = new JButton("Cancel");
//        g.gridx=2;
//        g.gridy=3;
//        gl.setConstraints(b2, g);
//        f1.add(b2);

        p1.add(b1);
        p1.add(b2);
        g.gridx = 1;
        g.gridy = 4;
        gl.setConstraints(p1, g);
        f1.add(p1);

        f1.pack();//View the component size automatically as required.

        f1.setVisible(true);
    }

    public static void main(String[] args) {
        UsingGridBagLayoutDesign ob = new UsingGridBagLayoutDesign();
    }
}
