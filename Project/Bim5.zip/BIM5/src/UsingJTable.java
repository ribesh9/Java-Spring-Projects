import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
public class UsingJTable {
//    JFrame f1;
    
    
    UsingJTable(){
       JFrame f1 = new JFrame();
        f1.setSize(500,500);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(new FlowLayout());
        
        String []cols = {"Id","Name","Salary","Position"};
        Object [][] data = {{1,"Ram",20000,"Manager"},{2,"Hari",30000,"Staff"}};
        JTable t1 = new JTable(data,cols);
        t1.setEnabled(false);
        t1.getTableHeader().setResizingAllowed(false);
        JScrollPane jp = new JScrollPane(t1);
        f1.add(jp);
        
        
        TableCellRenderer customRenderer = new DefaultTableCellRenderer() {
    public Component getTableCellRendererComponent(JTable table, Object value,
        boolean isSelected, boolean hasFocus, int row, int column) {
        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        if (column % 2== 0) {
            c.setBackground(Color.RED);
        }
        return c;
    }
};

// Set the custom renderer for the even-numbered columns
for (int i = 0; i < t1.getColumnModel().getColumnCount(); i++) {
    if (i+1 % 2 == 0) {
        t1.getColumnModel().getColumn(i).setCellRenderer(customRenderer);
    }
}
        f1.setVisible(true);
    }
    public static void main(String[] args) {
        UsingJTable t = new UsingJTable();
        
    }
}
//Disable the column resize
//Even number column bg color change
