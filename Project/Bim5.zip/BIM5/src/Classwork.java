import javax.swing.*;
import java.awt.*;
public class Classwork extends JFrame{
    JButton j1,j2;
    JLabel l1,l2,l3;
    JTextField t1,t2,t3;
    
    Classwork(){
        setSize(300,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FlowLayout fl = new FlowLayout();
        setLayout(fl);
        j1= new JButton("Submit");
        j2 = new JButton ("Cancel");
        l1 = new JLabel ("Name");
        l2 = new JLabel("Address");
        l3 = new JLabel("Email");
        t1 = new JTextField(20);
        t3 = new JTextField(20);
        t2 = new JTextField(20);
        add(l1);
        add(t1);
        add(l2);
        add(t2);
        add(l3);
        add(t3);
        add(j1);
        add(j2);
        setVisible(true);
    }
    public static void main(String[] args) {
        Classwork c = new Classwork();
    }
}
