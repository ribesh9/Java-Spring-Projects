
import javax.swing.*;
import java.awt.*;

public class UsingFlowLayout {

    JFrame f1;
    JButton b1, b2, b3, b4, b5;

    UsingFlowLayout() {
        f1 = new JFrame();
        f1.setSize(400,400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //f1.setVisible(true); This line does not add the button in the fram thus we keep in last
        FlowLayout fl = new FlowLayout(FlowLayout.CENTER,15,15);
//        FlowLayout fl = new FlowLayout(FlowLayout.CENTER);
        /*
            We can use the constructs as 
        a) FlowLayout()
        b)FlowLayout(int how)
        c)FlowLayout(int how,int horizontal,int vertical)
        */
        f1.setLayout(fl);
        b1 = new JButton("one");
        b2 = new JButton("two");
        b3 = new JButton("three");
        b4 = new JButton("four");
        b5 = new JButton("five");
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.add(b4);
        f1.add(b5);
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        UsingFlowLayout ob = new UsingFlowLayout();

    }
}
