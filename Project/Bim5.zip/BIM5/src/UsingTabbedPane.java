
import java.awt.*;
import javax.swing.*;
/*class StudentPanel extends JPanel implements ActionListener{
        JLabel l2, l1;
        JTextField t1;
         JComboBox cb;
         StudentPanel(){
             l1 = new JLabel("Name");
        l2 = new JLabel("Faculty");
         String f[] = {"Select a Faculty","BIM","BBM"};
        cb = new JComboBox(f);
         t1 = new JTextField(20);

         add(l1);
         add(t1);
         add(l2);
         add(cb);
         }
}*/
public class UsingTabbedPane {

    JFrame f1;
    JTabbedPane tp;
    JLabel l2, l1, l3, l4;
    JTextField t1, t2, t3, t4;
    JComboBox cb;
    JPanel p1, p2;

    UsingTabbedPane() {
        f1 = new JFrame();
        f1.setSize(800, 400);
        f1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f1.setLayout(new FlowLayout());

        l1 = new JLabel("Name");
        l2 = new JLabel("Faculty");
        l3 = new JLabel("Name");
        l4 = new JLabel("Phone");

        t1 = new JTextField(20);
        t2 = new JTextField(20);
        t3 = new JTextField(20);
        
        String f[] = {"Select a Faculty","BIM","BBM"};
        cb = new JComboBox(f);

        p1 = new JPanel();
        p2 = new JPanel();

        p1.add(l1);
        p1.add(t1);
        p1.add(l2);
        p1.add(cb);

        p2.add(l3);
        p2.add(t2);
        p2.add(l4);
        p2.add(t3);
        
        tp = new JTabbedPane();
        tp.addTab("Student", p1); //("Student",new StudentPanel());
        tp.addTab("Guardian", p2);
        f1.add(tp);
        
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        UsingTabbedPane ob = new UsingTabbedPane();
    }
}
