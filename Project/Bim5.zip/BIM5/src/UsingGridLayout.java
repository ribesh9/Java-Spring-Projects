
import javax.swing.*;
import java.awt.*;

public class UsingGridLayout {

    JFrame f1;
    JButton b1, b2, b3, b4, b5;

    UsingGridLayout() {
        f1 = new JFrame();
        f1.setSize(400, 400);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //f1.setVisible(true); This line does not add the button in the fram thus we keep in last
//        f1.setLayout(new BorderLayout(5,5));
        f1.setLayout(new GridLayout(3,2,5,5));
         /*Constructors of GridLayout are:
            1)GridLayout()
            2)GridLayout(int rows, int col)
            3)GridLayout(int rows,int col, int horz,int vert)
        */
        b1 = new JButton("one");
        b2 = new JButton("two");
        b3 = new JButton("three");
        b4 = new JButton("four");
        b5 = new JButton("five");
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.add(b4);
        f1.add(b5);
        //We need to write the region in the button for BorderLayout
        //The north, south, east, west side occupy each other expect center there remains
        //blank space for the center region.
        f1.setVisible(true);
    }

    public static void main(String[] args) {
        UsingGridLayout ob = new UsingGridLayout();
        
    }
}
