/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Applet;

import java.applet.*;
import java.awt.*;

public class MyApplet extends Applet
{
    public void paint(Graphics g)
    {
        //Font f = new Font("Algerian", Font.BOLD,20);
        //g.setFont(f);
        //g.setColor(Color.red);
        //g.drawString("Welcome To My Page", 10,30);
       //g.drawLine(10,20,200,10);
       //g.fillRect(10,20,200,100);
       g.setColor(Color.red);
       //g.drawString("TU",105,55);
       //g.drawOval(10, 10, 200, 100);
       // g.drawOval(10, 10, 100, 100);
        //g.fillOval(10,10,100,100);
        g.drawArc(10, 10, 200,100, 90,360);
       
    }
    
}
